# Repository Guidelines

## Project Structure & Module Organization
- `index.html` hosts the player UI; `images/` and `css/` provide artwork and styling (`player.css` main layout, `small.css` responsive tweaks).
- Core behavior lives in `js/player.js` (player runtime), `js/musicList.js` (playlist definitions/custom config), `js/lyric.js` (lyric parsing), and helpers in `js/functions.js`/`js/ajax.js`; jQuery plugins are under `js/jquery*.js` and `plugns/`.
- Backend entry points are `api.php` (Meting-backed music API) and `proxy.php` (proxy fallback); `plugns/Meting.php` and subfolders hold vendored libraries.
- `cache/` contains generated lyric/playlist JSON; treat it as runtime data and avoid committing new cache artifacts unless debugging a specific case.

## Build, Test, and Development Commands
- No build step is required; assets are static.
- Run locally with PHP 5.4+ and curl enabled: `php -S 127.0.0.1:8000 -t .` then open `http://127.0.0.1:8000/`.
- When touching API behavior, hit `api.php?server=netease&type=song&id=...` in the browser to sanity-check responses before wiring the UI.

## Coding Style & Naming Conventions
- JavaScript is ES5/jQuery-driven; stick to 4-space indentation, function declarations, and browser-compatible syntax (avoid new language features without polyfills). Preserve existing semicolon usage and verbose in-line comments.
- Keep configuration in `js/musicList.js` and `mkPlayer` settings in `js/player.js`; name new config flags with clear, lowerCamelCase keys.
- CSS favors descriptive class names already in `player.css`; mirror existing patterns instead of introducing utility-class systems.

## Testing Guidelines
- There are no automated tests; run manual passes after changes: load the homepage, search for a track, play/pause/skip, verify lyric sync and scrollbars, and test download/share buttons. On mobile or responsive mode, confirm tab switches and background effects render smoothly.
- For backend tweaks, validate a few sample `api.php` calls (success, empty result, and error cases) and ensure the UI shows friendly messages instead of raw errors.

## Commit & Pull Request Guidelines
- Use conventional-style subjects where possible (`feat: add lyric fallback`, `fix: handle empty playlist`); keep scope focused per commit.
- PRs should include: what changed and why, manual test notes or repro steps, and screenshots/GIFs for UI-visible adjustments. Avoid committing generated cache files unless explicitly needed for troubleshooting.

## Security & Configuration Tips
- Do not hardcode private API keys or user IDs; keep any environment-specific overrides in local config instead of the repo.
- Leave `mkPlayer.debug` false in committed code and avoid exposing stack traces from PHP endpoints; sanitize new logging to prevent leaking request details.
