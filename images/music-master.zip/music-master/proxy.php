<?php
/**
 * 简单的资源代理，限制在 B 站域名，避免直链防盗
 */

if (!isset($_GET['url'])) {
    http_response_code(400);
    exit('missing url');
}

$decoded = base64_decode($_GET['url'], true);
$target = $decoded !== false ? $decoded : $_GET['url'];

if (!filter_var($target, FILTER_VALIDATE_URL)) {
    http_response_code(400);
    exit('invalid url');
}

$parts = parse_url($target);
$host = $parts['host'] ?? '';

if (!isAllowedHost($host)) {
    http_response_code(403);
    exit('forbidden');
}

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $target);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0 Safari/537.36');

$headers = ['Referer: https://www.bilibili.com/'];
if (!empty($_SERVER['HTTP_RANGE'])) {
    $headers[] = 'Range: ' . $_SERVER['HTTP_RANGE'];
}
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

curl_setopt($ch, CURLOPT_HEADERFUNCTION, function ($ch, $header) {
    $len = strlen($header);
    $header = trim($header);
    if ($header === '') {
        return $len;
    }

    if (stripos($header, 'HTTP/') === 0) {
        $parts = explode(' ', $header);
        if (isset($parts[1]) && is_numeric($parts[1])) {
            http_response_code((int) $parts[1]);
        }
        return $len;
    }

    [$name, $value] = array_map('trim', explode(':', $header, 2) + ['', '']);
    $nameLower = strtolower($name);
    $passHeaders = ['content-type', 'content-length', 'accept-ranges', 'content-range'];
    if (in_array($nameLower, $passHeaders, true)) {
        header($name . ': ' . $value);
    }

    return $len;
});

curl_setopt($ch, CURLOPT_WRITEFUNCTION, function ($ch, $data) {
    echo $data;
    return strlen($data);
});

$body = curl_exec($ch);
$error = curl_errno($ch);
curl_close($ch);

if ($error) {
    http_response_code(502);
    exit('fetch failed');
}

header('Cache-Control: public, max-age=86400');

function isAllowedHost($host)
{
    $allowed = [
        'hdslb.com',
        'bilivideo.com',
    ];

    foreach ($allowed as $domain) {
        if ($host === $domain || substr($host, -strlen('.' . $domain)) === '.' . $domain) {
            return true;
        }
    }

    return false;
}
