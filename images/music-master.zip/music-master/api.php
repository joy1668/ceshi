<?php
/**
 * Bilibili audio helper for MKOnlinePlayer
 * 使用 B 站公开接口完成搜索、音频地址、封面和“伪歌词”（简介）获取
 */

define('DEBUG', false);

if (!DEBUG) {
    error_reporting(0);
}

// 路径常量，仅在需要时使用
define('CACHE_PATH', 'cache/');

$types = getParam('types');

switch ($types) {
    case 'search':
        handleSearch();
        break;
    case 'url':
        handlePlayUrl();
        break;
    case 'pic':
        handleCover();
        break;
    case 'lyric':
        handleLyric();
        break;
    case 'taihe_songlist':
        handleTaiheSonglist();
        break;
    case 'qq_hotlist':
        handleQqHotlist();
        break;
    default:
        defaultPage();
        break;
}

/**
 * 搜索 B 站视频，返回播放器所需的精简列表
 */
function handleSearch()
{
    $keyword = getParam('name', '');
    if ($keyword === '') {
        echojson(['code' => -1, 'msg' => 'keyword required']);
        return;
    }

    $page = max(1, intval(getParam('pages', 1)));
    $pageSize = max(1, intval(getParam('count', 20)));

    $resp = biliJson('https://api.bilibili.com/x/web-interface/search/type', [
        'search_type' => 'video',
        'page' => $page,
        'page_size' => $pageSize,
        'keyword' => $keyword,
    ]);

    if (!$resp || !isset($resp['data']['result'])) {
        echojson([]);
        return;
    }

    $list = [];
    foreach ($resp['data']['result'] as $item) {
        if (empty($item['bvid'])) {
            continue;
        }

        $title = cleanTitle($item['title'] ?? '');
        $author = $item['author'] ?? '未知UP主';
        $duration = formatDuration($item['duration'] ?? 0);

        $list[] = [
            'id' => $item['bvid'],
            'name' => $title,
            'artist' => [$author],
            'album' => '时长 ' . $duration,
            'source' => 'bilibili',
            'url_id' => $item['bvid'],
            'pic_id' => $item['bvid'],
            'lyric_id' => $item['bvid'],
        ];
    }

    echojson($list);
}

/**
 * 获取音频播放地址
 */
function handlePlayUrl()
{
    $bvid = getParam('id', '');
    if ($bvid === '') {
        echojson(['url' => '']);
        return;
    }

    $view = biliView($bvid);
    if (!$view || empty($view['cid'])) {
        echojson(['url' => '']);
        return;
    }

    $play = biliJson('https://api.bilibili.com/x/player/playurl', [
        'bvid' => $bvid,
        'cid' => $view['cid'],
        'qn' => 64,       // 64=高清；主要用来取 dash 音频
        'fnver' => 0,
        'fnval' => 16,    // 只要 dash
        'fourk' => 1,
    ]);

    $audioUrl = '';
    if (isset($play['data']['dash']['audio'][0])) {
        $audio = $play['data']['dash']['audio'][0];
        $audioUrl = $audio['baseUrl'] ?? $audio['base_url'] ?? '';
    } elseif (isset($play['data']['durl'][0]['url'])) {
        $audioUrl = $play['data']['durl'][0]['url'];
    }

    $proxied = $audioUrl ? proxyUrl($audioUrl) : '';

    echojson(['url' => $proxied]);
}

/**
 * 获取封面地址
 */
function handleCover()
{
    $bvid = getParam('id', '');
    if ($bvid === '') {
        echojson(['url' => '']);
        return;
    }

    $view = biliView($bvid);
    if (!$view || empty($view['pic'])) {
        echojson(['url' => '']);
        return;
    }

    echojson(['url' => proxyUrl($view['pic'])]);
}

/**
 * 使用视频简介生成伪歌词
 */
function handleLyric()
{
    $bvid = getParam('id', '');
    if ($bvid === '') {
        echojson(['lyric' => '']);
        return;
    }

    $view = biliView($bvid);
    if (!$view) {
        echojson(['lyric' => '']);
        return;
    }

    $desc = $view['desc'] ?? '';
    $lyric = buildLyricFromDesc($desc);

    echojson(['lyric' => $lyric]);
}

/**
 * 默认页面：简单输出提示
 */
function defaultPage()
{
    echo '<!doctype html><html><head><meta charset="utf-8"><title>信息</title><style>* {font-family: microsoft yahei}</style></head><body>';
    echo '<h2>Bilibili 音乐 API</h2>';
    echo '<p>可用接口: types=search|url|pic|lyric</p>';
    if (DEBUG) {
        echo '<p>PHP 版本：' . phpversion() . '</p>';
    }
    echo '</body></html>';
}

/**
 * 读取 GET/POST 参数
 */
function getParam($key, $default = '')
{
    return trim($key && is_string($key) ? (isset($_POST[$key]) ? $_POST[$key] : (isset($_GET[$key]) ? $_GET[$key] : $default)) : $default);
}

/**
 * JSON/JSONP 输出
 */
function echojson($data)
{
    header('Content-Type: application/json');
    $callback = getParam('callback');

    if (is_array($data) || is_object($data)) {
        $data = json_encode($data, JSON_UNESCAPED_UNICODE);
    }

    if ($callback) {
        die(htmlspecialchars($callback) . '(' . $data . ')');
    }

    die($data);
}

/**
 * 访问 B 站接口，自动带上指纹 Cookie
 */
function biliJson($url, $params = [])
{
    $resp = biliRequest($url, $params);
    if ($resp['error']) {
        return null;
    }

    return json_decode($resp['body'], true);
}

/**
 * 处理 B 站请求
 */
function biliRequest($url, $params = [])
{
    $cookie = biliCookie();

    if (!empty($params)) {
        $url .= (strpos($url, '?') === false ? '?' : '&') . http_build_query($params);
    }

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
    curl_setopt($ch, CURLOPT_TIMEOUT, 20);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0 Safari/537.36');
    $headers = [
        'Referer: https://www.bilibili.com/',
    ];
    if ($cookie) {
        $headers[] = 'Cookie: ' . $cookie;
    }
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $body = curl_exec($ch);
    $error = curl_errno($ch);
    $info = curl_getinfo($ch);
    curl_close($ch);

    return [
        'body' => $body,
        'error' => $error,
        'info' => $info,
    ];
}

/**
 * 获取百度千千（太合）歌单页面，解析标题
 */
function handleTaiheSonglist()
{
    $resp = httpGet('https://music.taihe.com/songlist');
    if ($resp['error'] || empty($resp['body'])) {
        echojson([]);
        return;
    }

    $html = $resp['body'];
    $titles = [];

    if (preg_match_all('/title:"([^"]+)"/', $html, $match)) {
        $titles = $match[1];
    } elseif (preg_match_all('/<div class="name"[^>]*>([^<]+)<\\/div>/', $html, $match)) {
        $titles = $match[1];
    }

    $titles = array_values(array_unique(array_map('trim', $titles)));
    if (count($titles) > 60) {
        $titles = array_slice($titles, 0, 60);
    }

    $data = array_map(function ($t) {
        return ['title' => html_entity_decode($t, ENT_QUOTES, 'UTF-8')];
    }, $titles);

    echojson($data);
}

/**
 * QQ音乐热歌榜（榜单ID 26）
 */
function handleQqHotlist()
{
    $resp = httpGet('https://y.qq.com/n/ryqq_v2/toplist/26');
    if ($resp['error'] || empty($resp['body'])) {
        echojson([]);
        return;
    }

    $html = $resp['body'];
    $songs = [];

    if (preg_match('/"rankList":(\[.*?\]),"historyarr"/s', $html, $match)) {
        $data = json_decode($match[1], true);
        if (is_array($data)) {
            foreach ($data as $item) {
                if (empty($item['title'])) {
                    continue;
                }
                $title = $item['title'];
                if (!empty($item['singerName'])) {
                    $title .= ' - ' . $item['singerName'];
                }
                $songs[] = ['title' => $title];
            }
        }
    }

    if (empty($songs)) {
        // 兜底：解析歌曲行
        if (preg_match_all('/songDetail\\/[^"]+">([^<]+)<\\/a><\\/span>.*?playlist__author"[^>]*>([^<]+)</s', $html, $m)) {
            for ($i = 0; $i < count($m[1]); $i++) {
                $title = html_entity_decode($m[1][$i], ENT_QUOTES, 'UTF-8');
                $singer = html_entity_decode($m[2][$i], ENT_QUOTES, 'UTF-8');
                $songs[] = ['title' => $title . ' - ' . $singer];
            }
        }
    }

    if (count($songs) > 100) {
        $songs = array_slice($songs, 0, 100);
    }

    echojson($songs);
}

/**
 * 获取 buvid Cookie
 */
function biliCookie()
{
    static $cookie = null;

    if ($cookie !== null) {
        return $cookie;
    }

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://api.bilibili.com/x/frontend/finger/spi');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
    curl_setopt($ch, CURLOPT_TIMEOUT, 20);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0 Safari/537.36');
    $body = curl_exec($ch);
    curl_close($ch);

    $data = json_decode($body, true);

    $cookies = [];
    if (!empty($data['data']['b_3'])) {
        $cookies[] = 'buvid3=' . $data['data']['b_3'];
    }
    if (!empty($data['data']['b_4'])) {
        $cookies[] = 'buvid4=' . $data['data']['b_4'];
    }
    if (!empty($data['data']['b_lsid'])) {
        $cookies[] = 'b_lsid=' . $data['data']['b_lsid'];
    }

    $cookie = implode('; ', $cookies);

    return $cookie;
}

/**
 * 简单 GET
 */
function httpGet($url)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
    curl_setopt($ch, CURLOPT_TIMEOUT, 20);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0 Safari/537.36');
    curl_setopt($ch, CURLOPT_ENCODING, '');
    $body = curl_exec($ch);
    $error = curl_errno($ch);
    $info = curl_getinfo($ch);
    curl_close($ch);

    return ['body' => $body, 'error' => $error, 'info' => $info];
}

/**
 * 获取视频 view 信息
 */
function biliView($bvid)
{
    $resp = biliJson('https://api.bilibili.com/x/web-interface/view', ['bvid' => $bvid]);
    if (!$resp || empty($resp['data'])) {
        return null;
    }

    $data = $resp['data'];
    if (empty($data['cid']) && !empty($data['pages'][0]['cid'])) {
        $data['cid'] = $data['pages'][0]['cid'];
    }

    return $data;
}

/**
 * 清理搜索标题
 */
function cleanTitle($title)
{
    $title = str_replace(['<em class="keyword">', '</em>'], '', $title);
    return html_entity_decode(strip_tags($title), ENT_QUOTES, 'UTF-8');
}

/**
 * 秒 -> mm:ss
 */
function formatDuration($seconds)
{
    $seconds = intval($seconds);
    $m = floor($seconds / 60);
    $s = $seconds % 60;
    return sprintf('%02d:%02d', $m, $s);
}

/**
 * 根据简介生成伪歌词
 */
function buildLyricFromDesc($desc)
{
    $desc = trim((string) $desc);
    if ($desc === '') {
        return '';
    }

    $lines = preg_split('/\r\n|\r|\n/', $desc);
    $time = 0;
    $step = 4; // 每行占用 4 秒
    $result = ['[00:00.00]Bilibili 视频简介（自动生成）'];

    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '') {
            continue;
        }
        $result[] = sprintf('[%02d:%05.2f]%s', floor($time / 60), $time % 60, $line);
        $time += $step;
    }

    return implode("\n", $result);
}

/**
 * 生成代理地址
 */
function proxyUrl($url)
{
    return 'proxy.php?url=' . urlencode(base64_encode($url));
}
